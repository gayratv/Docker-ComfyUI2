These are .bat files. Instruction files that run on your windows machines and execute actions. 

1. First use/double-click Windows_install.bat this will download and install Framepack and it's dependencies. It will download and install in the same folder as these files.
2. As it installs one or several terminal windows will open. Once it's complete you will see this text "echo FramePack installed check out all messages and save them before close to verify any errors or not later"
3. Next use Windows_update to ensure everything is up to date
4. Finally use Windows_start_App.bat to launch it.